﻿namespace WindowsFormsApp10
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabbbb = new System.Windows.Forms.TabControl();
            this.sad = new System.Windows.Forms.TabPage();
            this.insertListBox = new System.Windows.Forms.ListBox();
            this.ff = new System.Windows.Forms.TabPage();
            this.deleteListBox = new System.Windows.Forms.ListBox();
            this.dddddd = new System.Windows.Forms.TabPage();
            this.orderRecordListBox = new System.Windows.Forms.ListBox();
            this.tab1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.balanceDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.outstandingDataGridView = new System.Windows.Forms.DataGridView();
            this.autoRuleDataGridView = new System.Windows.Forms.DataGridView();
            this.거래규칙_번호 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_조건식 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_매입제한_금액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_매입제한_종목_개수 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_종목당_매수금액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_매수_거래구분 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_매도_거래구분 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_이익률 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_손절률 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래규칙_상태 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.todayProfitRateLabel = new System.Windows.Forms.Label();
            this.todayProfitLabel = new System.Windows.Forms.Label();
            this.totalEstimateLabel = new System.Windows.Forms.Label();
            this.totalBuyLabel = new System.Windows.Forms.Label();
            this.depositLabel = new System.Windows.Forms.Label();
            this.accountComboBox = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.orderComboBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.stockCodeLabel = new System.Windows.Forms.Label();
            this.stockSearchButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.stockTextBox = new System.Windows.Forms.TextBox();
            this.orderNumberNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.orderPriceNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.sellButton = new System.Windows.Forms.Button();
            this.buyButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.limitLossNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.limitProfitRateNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.orderCancelButton = new System.Windows.Forms.Button();
            this.SellAllStockButton = new System.Windows.Forms.Button();
            this.orderFixButton = new System.Windows.Forms.Button();
            this.balanceCheckButton = new System.Windows.Forms.Button();
            this.dd1 = new System.Windows.Forms.Label();
            this.setAutoTradingRuleButton = new System.Windows.Forms.Button();
            this.autoSellOrderComboBox = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.limitBuyingPerStockLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.limitNumberNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.limitPriceNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.conditionComboBox = new System.Windows.Forms.ComboBox();
            this.매입제한금액 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.autoTradingStartButton = new System.Windows.Forms.Button();
            this.autoTradingStopButton = new System.Windows.Forms.Button();
            this.autoBuyOrderComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.tabbbb.SuspendLayout();
            this.sad.SuspendLayout();
            this.ff.SuspendLayout();
            this.dddddd.SuspendLayout();
            this.tab1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.balanceDataGridView)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.outstandingDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.autoRuleDataGridView)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderNumberNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderPriceNumericUpDown)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limitLossNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.limitProfitRateNumericUpDown)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limitNumberNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.limitPriceNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabbbb
            // 
            this.tabbbb.Controls.Add(this.sad);
            this.tabbbb.Controls.Add(this.ff);
            this.tabbbb.Controls.Add(this.dddddd);
            this.tabbbb.Location = new System.Drawing.Point(639, 409);
            this.tabbbb.Name = "tabbbb";
            this.tabbbb.SelectedIndex = 0;
            this.tabbbb.Size = new System.Drawing.Size(422, 202);
            this.tabbbb.TabIndex = 33;
            // 
            // sad
            // 
            this.sad.Controls.Add(this.insertListBox);
            this.sad.Location = new System.Drawing.Point(4, 22);
            this.sad.Name = "sad";
            this.sad.Padding = new System.Windows.Forms.Padding(3);
            this.sad.Size = new System.Drawing.Size(414, 176);
            this.sad.TabIndex = 0;
            this.sad.Text = "편입종목";
            this.sad.UseVisualStyleBackColor = true;
            // 
            // insertListBox
            // 
            this.insertListBox.FormattingEnabled = true;
            this.insertListBox.ItemHeight = 12;
            this.insertListBox.Location = new System.Drawing.Point(0, 1);
            this.insertListBox.Name = "insertListBox";
            this.insertListBox.Size = new System.Drawing.Size(418, 172);
            this.insertListBox.TabIndex = 0;
            // 
            // ff
            // 
            this.ff.Controls.Add(this.deleteListBox);
            this.ff.Location = new System.Drawing.Point(4, 22);
            this.ff.Name = "ff";
            this.ff.Padding = new System.Windows.Forms.Padding(3);
            this.ff.Size = new System.Drawing.Size(414, 176);
            this.ff.TabIndex = 1;
            this.ff.Text = "이탈종목";
            this.ff.UseVisualStyleBackColor = true;
            // 
            // deleteListBox
            // 
            this.deleteListBox.FormattingEnabled = true;
            this.deleteListBox.ItemHeight = 12;
            this.deleteListBox.Location = new System.Drawing.Point(0, 0);
            this.deleteListBox.Name = "deleteListBox";
            this.deleteListBox.Size = new System.Drawing.Size(418, 172);
            this.deleteListBox.TabIndex = 0;
            // 
            // dddddd
            // 
            this.dddddd.Controls.Add(this.orderRecordListBox);
            this.dddddd.Location = new System.Drawing.Point(4, 22);
            this.dddddd.Name = "dddddd";
            this.dddddd.Padding = new System.Windows.Forms.Padding(3);
            this.dddddd.Size = new System.Drawing.Size(414, 176);
            this.dddddd.TabIndex = 2;
            this.dddddd.Text = "주문기록";
            this.dddddd.UseVisualStyleBackColor = true;
            // 
            // orderRecordListBox
            // 
            this.orderRecordListBox.FormattingEnabled = true;
            this.orderRecordListBox.ItemHeight = 12;
            this.orderRecordListBox.Location = new System.Drawing.Point(0, 1);
            this.orderRecordListBox.Name = "orderRecordListBox";
            this.orderRecordListBox.Size = new System.Drawing.Size(418, 172);
            this.orderRecordListBox.TabIndex = 0;
            // 
            // tab1
            // 
            this.tab1.Controls.Add(this.tabPage1);
            this.tab1.Controls.Add(this.tabPage2);
            this.tab1.Location = new System.Drawing.Point(35, 405);
            this.tab1.Name = "tab1";
            this.tab1.SelectedIndex = 0;
            this.tab1.Size = new System.Drawing.Size(571, 206);
            this.tab1.TabIndex = 32;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.balanceDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(563, 180);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "잔고";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // balanceDataGridView
            // 
            this.balanceDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.balanceDataGridView.Location = new System.Drawing.Point(0, 0);
            this.balanceDataGridView.Name = "balanceDataGridView";
            this.balanceDataGridView.RowHeadersVisible = false;
            this.balanceDataGridView.RowTemplate.Height = 23;
            this.balanceDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.balanceDataGridView.Size = new System.Drawing.Size(560, 177);
            this.balanceDataGridView.TabIndex = 23;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.outstandingDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(563, 180);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "미체결";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // outstandingDataGridView
            // 
            this.outstandingDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.outstandingDataGridView.Location = new System.Drawing.Point(0, 3);
            this.outstandingDataGridView.Name = "outstandingDataGridView";
            this.outstandingDataGridView.RowHeadersVisible = false;
            this.outstandingDataGridView.RowTemplate.Height = 23;
            this.outstandingDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.outstandingDataGridView.Size = new System.Drawing.Size(566, 180);
            this.outstandingDataGridView.TabIndex = 24;
            // 
            // autoRuleDataGridView
            // 
            this.autoRuleDataGridView.AllowUserToAddRows = false;
            this.autoRuleDataGridView.AllowUserToDeleteRows = false;
            this.autoRuleDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.autoRuleDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.거래규칙_번호,
            this.거래규칙_조건식,
            this.거래규칙_매입제한_금액,
            this.거래규칙_매입제한_종목_개수,
            this.거래규칙_종목당_매수금액,
            this.거래규칙_매수_거래구분,
            this.거래규칙_매도_거래구분,
            this.거래규칙_이익률,
            this.거래규칙_손절률,
            this.거래규칙_상태});
            this.autoRuleDataGridView.Location = new System.Drawing.Point(35, 237);
            this.autoRuleDataGridView.Name = "autoRuleDataGridView";
            this.autoRuleDataGridView.RowHeadersVisible = false;
            this.autoRuleDataGridView.RowTemplate.Height = 23;
            this.autoRuleDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.autoRuleDataGridView.Size = new System.Drawing.Size(1026, 162);
            this.autoRuleDataGridView.TabIndex = 31;
            // 
            // 거래규칙_번호
            // 
            this.거래규칙_번호.FillWeight = 60F;
            this.거래규칙_번호.HeaderText = "번호";
            this.거래규칙_번호.Name = "거래규칙_번호";
            this.거래규칙_번호.Width = 60;
            // 
            // 거래규칙_조건식
            // 
            this.거래규칙_조건식.HeaderText = "조건식";
            this.거래규칙_조건식.Name = "거래규칙_조건식";
            this.거래규칙_조건식.Width = 70;
            // 
            // 거래규칙_매입제한_금액
            // 
            this.거래규칙_매입제한_금액.HeaderText = "매입제한_금액";
            this.거래규칙_매입제한_금액.Name = "거래규칙_매입제한_금액";
            this.거래규칙_매입제한_금액.Width = 110;
            // 
            // 거래규칙_매입제한_종목_개수
            // 
            this.거래규칙_매입제한_종목_개수.HeaderText = "매입제한_종목_개수";
            this.거래규칙_매입제한_종목_개수.MinimumWidth = 140;
            this.거래규칙_매입제한_종목_개수.Name = "거래규칙_매입제한_종목_개수";
            this.거래규칙_매입제한_종목_개수.Width = 140;
            // 
            // 거래규칙_종목당_매수금액
            // 
            this.거래규칙_종목당_매수금액.HeaderText = "종목당_매수금액";
            this.거래규칙_종목당_매수금액.MinimumWidth = 130;
            this.거래규칙_종목당_매수금액.Name = "거래규칙_종목당_매수금액";
            this.거래규칙_종목당_매수금액.Width = 130;
            // 
            // 거래규칙_매수_거래구분
            // 
            this.거래규칙_매수_거래구분.HeaderText = "매수_거래구분";
            this.거래규칙_매수_거래구분.MinimumWidth = 120;
            this.거래규칙_매수_거래구분.Name = "거래규칙_매수_거래구분";
            this.거래규칙_매수_거래구분.Width = 120;
            // 
            // 거래규칙_매도_거래구분
            // 
            this.거래규칙_매도_거래구분.HeaderText = "매도_거래구분";
            this.거래규칙_매도_거래구분.MinimumWidth = 120;
            this.거래규칙_매도_거래구분.Name = "거래규칙_매도_거래구분";
            this.거래규칙_매도_거래구분.Width = 120;
            // 
            // 거래규칙_이익률
            // 
            this.거래규칙_이익률.HeaderText = "이익률";
            this.거래규칙_이익률.Name = "거래규칙_이익률";
            // 
            // 거래규칙_손절률
            // 
            this.거래규칙_손절률.HeaderText = "손절률";
            this.거래규칙_손절률.Name = "거래규칙_손절률";
            // 
            // 거래규칙_상태
            // 
            this.거래규칙_상태.HeaderText = "상태";
            this.거래규칙_상태.Name = "거래규칙_상태";
            this.거래규칙_상태.Width = 75;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.SystemColors.Window;
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.passwordTextBox, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.todayProfitRateLabel, 1, 6);
            this.tableLayoutPanel5.Controls.Add(this.todayProfitLabel, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.totalEstimateLabel, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.totalBuyLabel, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.depositLabel, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.accountComboBox, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label20, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.label19, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.label14, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.label15, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.label16, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(810, 13);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 7;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.03175F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.96825F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(251, 206);
            this.tableLayoutPanel5.TabIndex = 30;
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.passwordTextBox.Location = new System.Drawing.Point(129, 29);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(118, 21);
            this.passwordTextBox.TabIndex = 35;
            // 
            // todayProfitRateLabel
            // 
            this.todayProfitRateLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.todayProfitRateLabel.AutoSize = true;
            this.todayProfitRateLabel.Location = new System.Drawing.Point(129, 178);
            this.todayProfitRateLabel.Name = "todayProfitRateLabel";
            this.todayProfitRateLabel.Size = new System.Drawing.Size(118, 27);
            this.todayProfitRateLabel.TabIndex = 20;
            this.todayProfitRateLabel.Text = "0";
            this.todayProfitRateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // todayProfitLabel
            // 
            this.todayProfitLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.todayProfitLabel.AutoSize = true;
            this.todayProfitLabel.Location = new System.Drawing.Point(129, 142);
            this.todayProfitLabel.Name = "todayProfitLabel";
            this.todayProfitLabel.Size = new System.Drawing.Size(118, 35);
            this.todayProfitLabel.TabIndex = 20;
            this.todayProfitLabel.Text = "0";
            this.todayProfitLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalEstimateLabel
            // 
            this.totalEstimateLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.totalEstimateLabel.AutoSize = true;
            this.totalEstimateLabel.Location = new System.Drawing.Point(129, 113);
            this.totalEstimateLabel.Name = "totalEstimateLabel";
            this.totalEstimateLabel.Size = new System.Drawing.Size(118, 28);
            this.totalEstimateLabel.TabIndex = 20;
            this.totalEstimateLabel.Text = "0";
            this.totalEstimateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalBuyLabel
            // 
            this.totalBuyLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.totalBuyLabel.AutoSize = true;
            this.totalBuyLabel.Location = new System.Drawing.Point(129, 83);
            this.totalBuyLabel.Name = "totalBuyLabel";
            this.totalBuyLabel.Size = new System.Drawing.Size(118, 29);
            this.totalBuyLabel.TabIndex = 21;
            this.totalBuyLabel.Text = "0";
            this.totalBuyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // depositLabel
            // 
            this.depositLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.depositLabel.AutoSize = true;
            this.depositLabel.Location = new System.Drawing.Point(129, 55);
            this.depositLabel.Name = "depositLabel";
            this.depositLabel.Size = new System.Drawing.Size(118, 27);
            this.depositLabel.TabIndex = 20;
            this.depositLabel.Text = "0";
            this.depositLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // accountComboBox
            // 
            this.accountComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.accountComboBox.FormattingEnabled = true;
            this.accountComboBox.Location = new System.Drawing.Point(129, 4);
            this.accountComboBox.Name = "accountComboBox";
            this.accountComboBox.Size = new System.Drawing.Size(118, 20);
            this.accountComboBox.TabIndex = 20;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(4, 1);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(118, 24);
            this.label18.TabIndex = 3;
            this.label18.Text = "계좌번호";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 178);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(118, 27);
            this.label20.TabIndex = 19;
            this.label20.Text = "당일손익률";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 142);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(118, 35);
            this.label19.TabIndex = 18;
            this.label19.Text = "당일손익금액";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 113);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 28);
            this.label14.TabIndex = 16;
            this.label14.Text = "총평가금액";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(118, 29);
            this.label15.TabIndex = 15;
            this.label15.Text = "총매입금액";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 55);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 27);
            this.label16.TabIndex = 14;
            this.label16.Text = "예수금";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 28);
            this.label13.TabIndex = 21;
            this.label13.Text = "비밀번호";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.SystemColors.Window;
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.orderComboBox, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label9, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.stockCodeLabel, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.stockSearchButton, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.stockTextBox, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.orderNumberNumericUpDown, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.orderPriceNumericUpDown, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.sellButton, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.buyButton, 0, 5);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(551, 12);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 6;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.71429F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.28571F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(251, 207);
            this.tableLayoutPanel4.TabIndex = 29;
            // 
            // orderComboBox
            // 
            this.orderComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.orderComboBox.FormattingEnabled = true;
            this.orderComboBox.Location = new System.Drawing.Point(129, 60);
            this.orderComboBox.Name = "orderComboBox";
            this.orderComboBox.Size = new System.Drawing.Size(118, 20);
            this.orderComboBox.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 132);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(118, 38);
            this.label11.TabIndex = 16;
            this.label11.Text = "주문수량";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 37);
            this.label10.TabIndex = 15;
            this.label10.Text = "주문가격";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 36);
            this.label9.TabIndex = 14;
            this.label9.Text = "거래구분";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // stockCodeLabel
            // 
            this.stockCodeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stockCodeLabel.AutoSize = true;
            this.stockCodeLabel.Location = new System.Drawing.Point(129, 35);
            this.stockCodeLabel.Name = "stockCodeLabel";
            this.stockCodeLabel.Size = new System.Drawing.Size(118, 21);
            this.stockCodeLabel.TabIndex = 13;
            this.stockCodeLabel.Text = "0";
            this.stockCodeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // stockSearchButton
            // 
            this.stockSearchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stockSearchButton.BackColor = System.Drawing.Color.Thistle;
            this.stockSearchButton.Location = new System.Drawing.Point(129, 4);
            this.stockSearchButton.Name = "stockSearchButton";
            this.stockSearchButton.Size = new System.Drawing.Size(118, 27);
            this.stockSearchButton.TabIndex = 12;
            this.stockSearchButton.Text = "종목검색";
            this.stockSearchButton.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 21);
            this.label8.TabIndex = 3;
            this.label8.Text = "종목코드";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // stockTextBox
            // 
            this.stockTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stockTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.stockTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.stockTextBox.Location = new System.Drawing.Point(4, 4);
            this.stockTextBox.Name = "stockTextBox";
            this.stockTextBox.Size = new System.Drawing.Size(118, 21);
            this.stockTextBox.TabIndex = 8;
            this.stockTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // orderNumberNumericUpDown
            // 
            this.orderNumberNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.orderNumberNumericUpDown.Location = new System.Drawing.Point(129, 135);
            this.orderNumberNumericUpDown.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.orderNumberNumericUpDown.Name = "orderNumberNumericUpDown";
            this.orderNumberNumericUpDown.Size = new System.Drawing.Size(118, 21);
            this.orderNumberNumericUpDown.TabIndex = 2;
            // 
            // orderPriceNumericUpDown
            // 
            this.orderPriceNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.orderPriceNumericUpDown.Location = new System.Drawing.Point(129, 97);
            this.orderPriceNumericUpDown.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.orderPriceNumericUpDown.Name = "orderPriceNumericUpDown";
            this.orderPriceNumericUpDown.Size = new System.Drawing.Size(118, 21);
            this.orderPriceNumericUpDown.TabIndex = 7;
            // 
            // sellButton
            // 
            this.sellButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sellButton.BackColor = System.Drawing.Color.HotPink;
            this.sellButton.Location = new System.Drawing.Point(129, 174);
            this.sellButton.Name = "sellButton";
            this.sellButton.Size = new System.Drawing.Size(118, 29);
            this.sellButton.TabIndex = 18;
            this.sellButton.Text = "매도주문";
            this.sellButton.UseVisualStyleBackColor = false;
            // 
            // buyButton
            // 
            this.buyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buyButton.BackColor = System.Drawing.Color.HotPink;
            this.buyButton.Location = new System.Drawing.Point(4, 174);
            this.buyButton.Name = "buyButton";
            this.buyButton.Size = new System.Drawing.Size(118, 29);
            this.buyButton.TabIndex = 19;
            this.buyButton.Text = "매수주문";
            this.buyButton.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.Window;
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.limitLossNumericUpDown, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.limitProfitRateNumericUpDown, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.orderCancelButton, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.SellAllStockButton, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.orderFixButton, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.balanceCheckButton, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.dd1, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.setAutoTradingRuleButton, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.autoSellOrderComboBox, 1, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(309, 12);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.03175F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.96825F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(236, 207);
            this.tableLayoutPanel3.TabIndex = 28;
            // 
            // limitLossNumericUpDown
            // 
            this.limitLossNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.limitLossNumericUpDown.Location = new System.Drawing.Point(121, 34);
            this.limitLossNumericUpDown.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.limitLossNumericUpDown.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.limitLossNumericUpDown.Name = "limitLossNumericUpDown";
            this.limitLossNumericUpDown.Size = new System.Drawing.Size(111, 21);
            this.limitLossNumericUpDown.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 29);
            this.label7.TabIndex = 2;
            this.label7.Text = "이익률";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 33);
            this.label5.TabIndex = 3;
            this.label5.Text = "손절률";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // limitProfitRateNumericUpDown
            // 
            this.limitProfitRateNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.limitProfitRateNumericUpDown.Location = new System.Drawing.Point(121, 4);
            this.limitProfitRateNumericUpDown.Name = "limitProfitRateNumericUpDown";
            this.limitProfitRateNumericUpDown.Size = new System.Drawing.Size(111, 21);
            this.limitProfitRateNumericUpDown.TabIndex = 2;
            // 
            // orderCancelButton
            // 
            this.orderCancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.orderCancelButton.BackColor = System.Drawing.Color.Gold;
            this.orderCancelButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.orderCancelButton.Location = new System.Drawing.Point(4, 175);
            this.orderCancelButton.Name = "orderCancelButton";
            this.orderCancelButton.Size = new System.Drawing.Size(110, 28);
            this.orderCancelButton.TabIndex = 10;
            this.orderCancelButton.Text = "주문취소";
            this.orderCancelButton.UseVisualStyleBackColor = false;
            // 
            // SellAllStockButton
            // 
            this.SellAllStockButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SellAllStockButton.BackColor = System.Drawing.Color.Gold;
            this.SellAllStockButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SellAllStockButton.Location = new System.Drawing.Point(121, 175);
            this.SellAllStockButton.Name = "SellAllStockButton";
            this.SellAllStockButton.Size = new System.Drawing.Size(111, 28);
            this.SellAllStockButton.TabIndex = 9;
            this.SellAllStockButton.Text = "전체 청산";
            this.SellAllStockButton.UseVisualStyleBackColor = false;
            // 
            // orderFixButton
            // 
            this.orderFixButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.orderFixButton.BackColor = System.Drawing.Color.Gold;
            this.orderFixButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.orderFixButton.Location = new System.Drawing.Point(4, 141);
            this.orderFixButton.Name = "orderFixButton";
            this.orderFixButton.Size = new System.Drawing.Size(110, 27);
            this.orderFixButton.TabIndex = 8;
            this.orderFixButton.Text = "정정";
            this.orderFixButton.UseVisualStyleBackColor = false;
            // 
            // balanceCheckButton
            // 
            this.balanceCheckButton.BackColor = System.Drawing.Color.Gold;
            this.balanceCheckButton.Location = new System.Drawing.Point(121, 141);
            this.balanceCheckButton.Name = "balanceCheckButton";
            this.balanceCheckButton.Size = new System.Drawing.Size(111, 27);
            this.balanceCheckButton.TabIndex = 11;
            this.balanceCheckButton.Text = "잔고조회";
            this.balanceCheckButton.UseVisualStyleBackColor = false;
            // 
            // dd1
            // 
            this.dd1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dd1.AutoSize = true;
            this.dd1.Location = new System.Drawing.Point(4, 65);
            this.dd1.Name = "dd1";
            this.dd1.Size = new System.Drawing.Size(110, 37);
            this.dd1.TabIndex = 13;
            this.dd1.Text = "매도거래구분";
            this.dd1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // setAutoTradingRuleButton
            // 
            this.setAutoTradingRuleButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.setAutoTradingRuleButton.BackColor = System.Drawing.Color.DarkOrange;
            this.tableLayoutPanel3.SetColumnSpan(this.setAutoTradingRuleButton, 2);
            this.setAutoTradingRuleButton.Location = new System.Drawing.Point(4, 106);
            this.setAutoTradingRuleButton.Name = "setAutoTradingRuleButton";
            this.setAutoTradingRuleButton.Size = new System.Drawing.Size(228, 28);
            this.setAutoTradingRuleButton.TabIndex = 6;
            this.setAutoTradingRuleButton.Text = "조건식 거래규칙 설정";
            this.setAutoTradingRuleButton.UseVisualStyleBackColor = false;
            // 
            // autoSellOrderComboBox
            // 
            this.autoSellOrderComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.autoSellOrderComboBox.FormattingEnabled = true;
            this.autoSellOrderComboBox.Location = new System.Drawing.Point(121, 68);
            this.autoSellOrderComboBox.Name = "autoSellOrderComboBox";
            this.autoSellOrderComboBox.Size = new System.Drawing.Size(111, 20);
            this.autoSellOrderComboBox.TabIndex = 12;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.limitBuyingPerStockLabel, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.limitNumberNumericUpDown, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.limitPriceNumericUpDown, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.conditionComboBox, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.매입제한금액, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.autoTradingStartButton, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.autoTradingStopButton, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.autoBuyOrderComboBox, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(35, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.03175F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.96825F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(266, 207);
            this.tableLayoutPanel1.TabIndex = 27;
            // 
            // limitBuyingPerStockLabel
            // 
            this.limitBuyingPerStockLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.limitBuyingPerStockLabel.AutoSize = true;
            this.limitBuyingPerStockLabel.Location = new System.Drawing.Point(136, 102);
            this.limitBuyingPerStockLabel.Name = "limitBuyingPerStockLabel";
            this.limitBuyingPerStockLabel.Size = new System.Drawing.Size(126, 29);
            this.limitBuyingPerStockLabel.TabIndex = 19;
            this.limitBuyingPerStockLabel.Text = "0";
            this.limitBuyingPerStockLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 29);
            this.label12.TabIndex = 19;
            this.label12.Text = "종목당 매수금액";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // limitNumberNumericUpDown
            // 
            this.limitNumberNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.limitNumberNumericUpDown.Location = new System.Drawing.Point(136, 68);
            this.limitNumberNumericUpDown.Name = "limitNumberNumericUpDown";
            this.limitNumberNumericUpDown.Size = new System.Drawing.Size(126, 21);
            this.limitNumberNumericUpDown.TabIndex = 7;
            this.limitNumberNumericUpDown.ValueChanged += new System.EventHandler(this.limitNumberNumericUpDown_ValueChanged);
            // 
            // limitPriceNumericUpDown
            // 
            this.limitPriceNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.limitPriceNumericUpDown.Location = new System.Drawing.Point(136, 34);
            this.limitPriceNumericUpDown.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.limitPriceNumericUpDown.Name = "limitPriceNumericUpDown";
            this.limitPriceNumericUpDown.Size = new System.Drawing.Size(126, 21);
            this.limitPriceNumericUpDown.TabIndex = 2;
            // 
            // conditionComboBox
            // 
            this.conditionComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.conditionComboBox.FormattingEnabled = true;
            this.conditionComboBox.Location = new System.Drawing.Point(136, 4);
            this.conditionComboBox.Name = "conditionComboBox";
            this.conditionComboBox.Size = new System.Drawing.Size(126, 20);
            this.conditionComboBox.TabIndex = 2;
            // 
            // 매입제한금액
            // 
            this.매입제한금액.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.매입제한금액.AutoSize = true;
            this.매입제한금액.Location = new System.Drawing.Point(4, 31);
            this.매입제한금액.Name = "매입제한금액";
            this.매입제한금액.Size = new System.Drawing.Size(125, 33);
            this.매입제한금액.TabIndex = 3;
            this.매입제한금액.Text = "매입제한 금액";
            this.매입제한금액.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 36);
            this.label3.TabIndex = 4;
            this.label3.Text = "매입제한 종목 개수";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "조건식 선택";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // autoTradingStartButton
            // 
            this.autoTradingStartButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.autoTradingStartButton.BackColor = System.Drawing.Color.LightPink;
            this.autoTradingStartButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.autoTradingStartButton.Location = new System.Drawing.Point(4, 170);
            this.autoTradingStartButton.Name = "autoTradingStartButton";
            this.autoTradingStartButton.Size = new System.Drawing.Size(125, 33);
            this.autoTradingStartButton.TabIndex = 2;
            this.autoTradingStartButton.Text = "자동매매 시작";
            this.autoTradingStartButton.UseVisualStyleBackColor = false;
            // 
            // autoTradingStopButton
            // 
            this.autoTradingStopButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.autoTradingStopButton.BackColor = System.Drawing.Color.LightPink;
            this.autoTradingStopButton.Location = new System.Drawing.Point(136, 170);
            this.autoTradingStopButton.Name = "autoTradingStopButton";
            this.autoTradingStopButton.Size = new System.Drawing.Size(126, 33);
            this.autoTradingStopButton.TabIndex = 6;
            this.autoTradingStopButton.Text = "자동매매 중지";
            this.autoTradingStopButton.UseVisualStyleBackColor = false;
            // 
            // autoBuyOrderComboBox
            // 
            this.autoBuyOrderComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.autoBuyOrderComboBox.FormattingEnabled = true;
            this.autoBuyOrderComboBox.Location = new System.Drawing.Point(136, 135);
            this.autoBuyOrderComboBox.Name = "autoBuyOrderComboBox";
            this.autoBuyOrderComboBox.Size = new System.Drawing.Size(126, 20);
            this.autoBuyOrderComboBox.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 34);
            this.label4.TabIndex = 5;
            this.label4.Text = "거래구분";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(1108, 557);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 34;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1450, 649);
            this.Controls.Add(this.axKHOpenAPI1);
            this.Controls.Add(this.tabbbb);
            this.Controls.Add(this.tab1);
            this.Controls.Add(this.autoRuleDataGridView);
            this.Controls.Add(this.tableLayoutPanel5);
            this.Controls.Add(this.tableLayoutPanel4);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabbbb.ResumeLayout(false);
            this.sad.ResumeLayout(false);
            this.ff.ResumeLayout(false);
            this.dddddd.ResumeLayout(false);
            this.tab1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.balanceDataGridView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.outstandingDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.autoRuleDataGridView)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderNumberNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderPriceNumericUpDown)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limitLossNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.limitProfitRateNumericUpDown)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limitNumberNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.limitPriceNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabbbb;
        private System.Windows.Forms.TabPage sad;
        private System.Windows.Forms.TabPage ff;
        private System.Windows.Forms.TabPage dddddd;
        private System.Windows.Forms.TabControl tab1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView balanceDataGridView;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView outstandingDataGridView;
        private System.Windows.Forms.DataGridView autoRuleDataGridView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label todayProfitRateLabel;
        private System.Windows.Forms.Label todayProfitLabel;
        private System.Windows.Forms.Label totalEstimateLabel;
        private System.Windows.Forms.Label totalBuyLabel;
        private System.Windows.Forms.Label depositLabel;
        private System.Windows.Forms.ComboBox accountComboBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.ComboBox orderComboBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label stockCodeLabel;
        private System.Windows.Forms.Button stockSearchButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox stockTextBox;
        private System.Windows.Forms.NumericUpDown orderNumberNumericUpDown;
        private System.Windows.Forms.NumericUpDown orderPriceNumericUpDown;
        private System.Windows.Forms.Button sellButton;
        private System.Windows.Forms.Button buyButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button orderCancelButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown limitProfitRateNumericUpDown;
        private System.Windows.Forms.Button orderFixButton;
        private System.Windows.Forms.Button balanceCheckButton;
        private System.Windows.Forms.Button SellAllStockButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label limitBuyingPerStockLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown limitNumberNumericUpDown;
        private System.Windows.Forms.NumericUpDown limitPriceNumericUpDown;
        private System.Windows.Forms.ComboBox conditionComboBox;
        private System.Windows.Forms.Label 매입제한금액;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button autoTradingStartButton;
        private System.Windows.Forms.Button autoTradingStopButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox autoBuyOrderComboBox;
        private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.ListBox insertListBox;
        private System.Windows.Forms.ListBox deleteListBox;
        private System.Windows.Forms.ListBox orderRecordListBox;
        private System.Windows.Forms.NumericUpDown limitLossNumericUpDown;
        private System.Windows.Forms.ComboBox autoSellOrderComboBox;
        private System.Windows.Forms.Label dd1;
        private System.Windows.Forms.Button setAutoTradingRuleButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_번호;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_조건식;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_매입제한_금액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_매입제한_종목_개수;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_종목당_매수금액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_매수_거래구분;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_매도_거래구분;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_이익률;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_손절률;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래규칙_상태;
    }
}

